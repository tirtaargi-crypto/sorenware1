# SorenWare — One ZIP Upload Payload

This ZIP is the Android project payload for the repository's existing GitHub Actions ZIP builder.

For repository `tirtaargi-crypto/sorenware1`:
1. Upload this ZIP itself to the repository root.
2. The existing `.github/workflows/build-from-zip.yml` workflow extracts the ZIP and builds the debug APK.
3. Open GitHub Actions and run **Build SorenWare from ZIP** if it does not trigger automatically.
4. Download the `SorenWare-debug-apk` artifact from the completed workflow.

The Android project uses Java/Kotlin JVM target 17.
