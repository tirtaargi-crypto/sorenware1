package com.sorenware.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var device: TextView
    private lateinit var thermal: TextView
    private lateinit var refresh: TextView
    private lateinit var network: TextView
    private lateinit var touch: TextView
    private var touches = 0

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        device = findViewById(R.id.deviceText)
        thermal = findViewById(R.id.thermalText)
        refresh = findViewById(R.id.refreshText)
        network = findViewById(R.id.networkText)
        touch = findViewById(R.id.touchText)

        findViewById<android.widget.Button>(R.id.performanceButton).setOnClickListener {
            touch.text = "Performance profile selected. Monitoring active."
        }
        findViewById<android.widget.Button>(R.id.balancedButton).setOnClickListener {
            touch.text = "Balanced profile selected. Monitoring active."
        }
        findViewById<android.widget.Button>(R.id.displayButton).setOnClickListener {
            openSettings(Settings.ACTION_DISPLAY_SETTINGS)
        }
        findViewById<android.widget.Button>(R.id.batteryButton).setOnClickListener {
            openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        }
        updateInfo()
    }

    override fun onResume() {
        super.onResume()
        updateInfo()
    }

    private fun updateInfo() {
        device.text = "${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}"
        refresh.text = String.format(Locale.US, "Refresh rate: %.0f Hz", windowManager.defaultDisplay.refreshRate)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        thermal.text = "Thermal: " + if (Build.VERSION.SDK_INT >= 29) {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Light"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
                else -> "Unknown"
            }
        } else "Unsupported"

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val c = n?.let { cm.getNetworkCapabilities(it) }
        network.text = "Connection: " + when {
            c?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            c?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile data"
            c?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            else -> "Offline"
        }
    }

    private fun openSettings(action: String) {
        try { startActivity(Intent(action)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            touches++
            touch.text = "Touch check: $touches touch events detected."
        }
        return super.dispatchTouchEvent(event)
    }
}
